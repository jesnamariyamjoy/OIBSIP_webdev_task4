const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

// In-memory user storage
let users = [];

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: true
}));

app.use(express.static('public')); // Serve HTML/CSS/JS files

// Middleware to protect dashboard
function authMiddleware(req, res, next) {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/login.html');
  }
}

// Registration
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.send('All fields are required. <a href="/register.html">Back</a>');

  const existingUser = users.find(u => u.username === username);
  if (existingUser) return res.send('Username already exists. <a href="/register.html">Back</a>');

  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword });
  res.send('Registration successful! <a href="/login.html">Login</a>');
});

// Login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.send('Invalid username or password. <a href="/login.html">Back</a>');

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.send('Invalid username or password. <a href="/login.html">Back</a>');

  req.session.user = username;
  res.redirect('/dashboard');
});

// Dashboard
app.get('/dashboard', authMiddleware, (req, res) => {
  res.send(`
    <html>
      <head>
        <link rel="stylesheet" href="/style.css">
        <title>Dashboard</title>
      </head>
      <body>
        <div class="container">
          <h1>Welcome ${req.session.user}!</h1>
          <p>This is a secured page accessible only after login.</p>
          <a href="/logout" class="btn">Logout</a>
        </div>
      </body>
    </html>
  `);
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login.html');
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
